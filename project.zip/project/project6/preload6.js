const {contextBridge,ipcRenderer}=require('electron');
const sqlite3 = require('sqlite3').verbose();

let db = new sqlite3.Database('./baza.db');

let sqlupdate=(kolicina,sifra)=>{
    return new Promise((resolve,reject)=>{

        console.log(kolicina,sifra);
    
    db.run(`update skladiste set kolicina where id=?`, [sifra], function(err) {
      if (err) {
        return console.log(err.message);
      }
      // get the last insert id
      resolve(`A row has been inserted with rowid ${this.lastID}`);
    });
})
}

window.addEventListener('DOMContentLoaded', () => {
   
   // document.getElementById('xx').onclick=function (){myCreateFunction()};
      
   document.querySelector("#zatvori").addEventListener("click",closeWindow);

        function closeWindow(){
            let kolicinax=document.querySelector("#kolicina").value;
            let sifrax=document.querySelector("#sifra").value;

            console.log(kolicinax," ",sifrax)


            console.log("Skladisnica console")
            //window.apiunos.sqlunos(idx,artiklx,pdvx,kolicinax,mjerax,cijenax);
            //window.apiunos.sendMsg("pong unos");
            ipcRenderer.send('message-from-window6','Zatvori skladisnica prozor');
        }

    
});