const { app, BrowserWindow , ipcMain} = require('electron')
const path = require('path')
const url =require('url');

let win,skladiste,unos,blagajna,sifrarnik,skladisnica,brisanje,djelatnici,cijene;

const createWindow = () => {
  win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
        contextIsolation:true,
        sandbox: false,
      preload: path.join(__dirname, './preload_index.js')
    }
  })

    win.loadFile('./index.html')
    let wc=win.webContents;
    wc.openDevTools();
  
      win.on('closed', () => {
      win = null
      })
}

app.whenReady().then(() => {
    createWindow()
})

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
  })
  
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })


  // win.on('closed', () => {
  //   win = null
  // });

    

  ipcMain.handle("get/blagajna",async (event,args)=>{
    console.log(args);

    // if (blagajna) {
    //   blagajna.close();
    // }
    
    blagajna=new BrowserWindow({
        //parent:win,
        width:1000,
        height:600,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            sandbox: false,
            preload:path.join(__dirname,'./preload1.js'),
        },
    });

    blagajna.on('closed', () => {
      blagajna=null;
      console.log("blagajna closed xxxx")
    })

    blagajna.loadFile('./blagajna.html');
    
    blagajna.webContents.openDevTools();
    blagajna.show();

    //event.sender.send("skladiste","message")
    return 1;
  }
  )


  ipcMain.handle("get/unos",async (event,args)=>{
    console.log(args);
    
    unos=new BrowserWindow({
        //parent:win,
        width:400,
        height:300,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            sandbox: false,
            preload:path.join(__dirname,'./preload2.js'),
        },
    });

    unos.on('closed', () => {
      unos=null;
    })

    unos.loadFile('./unos.html');
    unos.webContents.openDevTools();
    unos.show();

    //event.sender.send("skladiste","message")
    return 1;
  }
  )
 


  ipcMain.handle("get/version",async (event,args)=>{
    console.log(args);

    
    
    skladiste=new BrowserWindow({
        //parent:win,
        width:600,
        height:800,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:false,
            contextIsolation:true,
            sandbox: false,
            preload:path.join(__dirname,'./preload3.js'),
        },
    });

    skladiste.on('closed', () => {
      skladiste= null
  })

    //skladiste.loadFile('./skladiste.html');
    // skladiste.loadURL(url.format({
    //   pathname: path.join(__dirname, './skladiste.html'), // important
    //   protocol: 'file:',
    //   slashes: true,
    //   // baseUrl: 'dist'
    // }));
    skladiste.loadFile('${__dirname}/skladiste.html');
    skladiste.webContents.openDevTools();
    skladiste.show();

    //event.sender.send("skladiste","message")
    return 1;
  }
  )


  ipcMain.handle("get/sifrarnik",async (event,args)=>{
    console.log(args);
      sifrarnik=new BrowserWindow({
        //parent:win,
        width:600,
        height:800,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            sandbox: false,
            preload:path.join(__dirname,'./preload5.js'),
        },
    });

    sifrarnik.on('closed', () => {
      sifrarnik= null
      console.log("sifrarnik closed xxxx")
  })

    sifrarnik.loadFile('./sifrarnik.html');
    sifrarnik.webContents.openDevTools();
    sifrarnik.show();

    //event.sender.send("skladiste","message")
    return 1;
  }
  )

  ipcMain.handle("get/skladisnica",async (event,args)=>{
    console.log(args);
      skladisnica=new BrowserWindow({
        //parent:win,
        width:600,
        height:800,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            sandbox: false,
            preload:path.join(__dirname,'./preload6.js'),
        },
    });

    skladisnica.on('closed', () => {
      skladisnica= null
      console.log("skladisnica closed xxxx")
  })

    skladisnica.loadFile('./skladisnica.html');
    skladisnica.webContents.openDevTools();
    skladisnica.show();

    //event.sender.send("skladiste","message")
    return 1;
  }
  )

  ipcMain.handle("get/brisanje",async (event,args)=>{
    console.log(args);
      brisanje=new BrowserWindow({
        //parent:win,
        width:600,
        height:800,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            sandbox: false,
            preload:path.join(__dirname,'./preload7.js'),
        },
    });

    brisanje.on('closed', () => {
      skladisnica= null
      console.log("brisanje closed xxxx")
  })

    brisanje.loadFile('./brisanje_artikla.html');
    brisanje.webContents.openDevTools();
    brisanje.show();

    //event.sender.send("skladiste","message")
    return 1;
  }
  )


  ipcMain.handle("get/djelatnici",async (event,args)=>{
    console.log(args);
      djelatnici=new BrowserWindow({
        //parent:win,
        width:600,
        height:800,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            sandbox: false,
            preload:path.join(__dirname,'./preload9.js'),
        },
    });

    djelatnici.on('closed', () => {
      djelatnici= null
      console.log("djelatnici closed xxxx")
  })

    djelatnici.loadFile('./djelatnici.html');
    djelatnici.webContents.openDevTools();
    djelatnici.show();

    //event.sender.send("skladiste","message")
    return 1;
  }
  )


  ipcMain.handle("get/cijene",async (event,args)=>{
    console.log(args);

    // if (blagajna) {
    //   blagajna.close();
    // }
    
    cijene=new BrowserWindow({
        //parent:win,
        width:1000,
        height:600,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            sandbox: false,
            preload:path.join(__dirname,'./preload8.js'),
        },
    });

    cijene.on('closed', () => {
      cijene=null;
      console.log("cijene closed xxxx")
    })

    cijene.loadFile('./cijene.html');
    cijene.webContents.openDevTools();
    cijene.show();

    //event.sender.send("skladiste","message")
    return 1;
  }
  )
 
  ipcMain.on('message-from-window1',(event,args)=>{
    //win.webContents.send("message-enable-button1","enable 1");
    console.log('main received prozor 1',args);
    blagajna.close();
    blagajna=!blagajna;
    
})

  ipcMain.on('message-from-window2',(event,args)=>{
    //win.webContents.send("message-enable-button1","enable 1");
    console.log('main received prozor 2',args);
    unos.close();
    unos=!unos;
})

  ipcMain.on('message-from-window3',(event,args)=>{
    //win.webContents.send("message-enable-button1","enable 1");
    console.log('main received prozor 3',args);
    skladiste.close();
    skladiste=!skladiste;
})



ipcMain.on('message-from-window5',(event,args)=>{
  //win.webContents.send("message-enable-button1","enable 1");
  console.log('main received prozor 5',args);
  sifrarnik.close();
  sifrarnik=!sifrarnik;
})


ipcMain.on('message-from-window6',(event,args)=>{
  //win.webContents.send("message-enable-button1","enable 1");
  console.log('main received prozor 6',args);
  skladisnica.close();
  skladisnica=!skladisnica;
})

ipcMain.on('message-from-window7',(event,args)=>{
  //win.webContents.send("message-enable-button1","enable 1");
  console.log('main received prozor 7',args);
  brisanje.close();
  brisanje=!brisanje;
})

ipcMain.on('message-from-window8',(event,args)=>{
  //win.webContents.send("message-enable-button1","enable 1");
  console.log('main received prozor 8',args);
  cijene.close();
  cijene=!cijene;
})

ipcMain.on('message-from-window9',(event,args)=>{
  //win.webContents.send("message-enable-button1","enable 1");
  console.log('main received prozor 9',args);
  djelatnici.close();
  djelatnici=!djelatnici;
})



ipcMain.on('get/izlaz',(event,args)=>{
  //win.webContents.send("message-enable-button1","enable 1");
  console.log('main received ',args);
  
  if (skladiste) {
    skladiste.close();
    console.log("skladiste closed");
  }

  if (unos) {
    unos.close();
    console.log("Unos closed");
  }
   

  if (blagajna) {
    blagajna.close();
    console.log("Blagajna closed");
  }

  if (sifrarnik) {
    sifrarnik.close();
    console.log("Sifrarnik closed");
  }

  if (skladisnica) {
    skladisnica.close();
    console.log("Skladisnicaclosed");
  }

  if (brisanje) {
    brisanje.close();
    console.log("Brisanje artikla closed");
  }

  if (djelatnici) {
    djelatnici.close();
    console.log("Unos djelatnika closed");
  }

  if (cijene) {
    cijene.close();
    console.log("Promijena cijene closed");
  }
  
  win.close();
  console.log("win closed");

})

