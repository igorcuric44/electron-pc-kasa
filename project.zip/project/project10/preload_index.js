const {contextBridge,ipcRenderer}=require('electron');

const API={
    get_version:(msg)=>ipcRenderer.invoke("get/version",msg),
    get_unos:(msg)=>ipcRenderer.invoke("get/unos",msg),
    get_blagajna:(msg)=>ipcRenderer.invoke("get/blagajna",msg),
    get_sifrarnik:(msg)=>ipcRenderer.invoke("get/sifrarnik",msg),
    get_skladisnica:(msg)=>ipcRenderer.invoke("get/skladisnica",msg),
    get_brisanje:(msg)=>ipcRenderer.invoke("get/brisanje",msg),
    get_cijene:(msg)=>ipcRenderer.invoke("get/cijene",msg),
    get_djelatnici:(msg)=>ipcRenderer.invoke("get/djelatnici",msg),
    sendMsg:(msg)=>ipcRenderer.send("get/izlaz",msg),
}

contextBridge.exposeInMainWorld('api',API);