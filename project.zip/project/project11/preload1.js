const {contextBridge,ipcRenderer}=require('electron');
const sqlite3 = require('sqlite3').verbose();

let db = new sqlite3.Database('./baza.db');

const API={
    sendMsg:(msg)=>ipcRenderer.send("message-from-window1",msg),
    sqlupit:sqlupit,
}

contextBridge.exposeInMainWorld('apiblagajna',API);


var sqlupit=(id)=>{
  return new Promise((resolve,reject)=>{
  let sql = `SELECT * FROM skladiste where id=?`;
      db.all(sql,[id], function (err, rows) {
          if(err){
              reject(new Error(
                "This promise is Rejected..."));
          }else{
          resolve(rows);
          }
      }); 
  })
  }

  window.addEventListener('DOMContentLoaded', () => {
   
  document.getElementById('xx').onclick=function (){myCreateFunction()};
  document.getElementById('yy').addEventListener("click",myDeleteFunction);


  let str="";
  let s=0,ss=0;
  let row;
let cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8;
let myTable;
let kk;
let n;
let t;
let suma=0;
let printstr;

     document.getElementById('area').addEventListener("keypress", async function(event) {
 event.preventDefault();
 console.log(event.key);
 

      if(event.key=="0")
        str+="0";
      else if(event.key=="1")
        str+="1";
      else if(event.key=="2")
        str+="2";
      else if(event.key=="3")
        str+="3";
      else if(event.key=="4")
        str+="4";
      else if(event.key=="5")
        str+="5";
      else if(event.key=="6")
        str+="6";
      else if(event.key=="7")
        str+="7";
      else if(event.key=="8")
        str+="8";
      else if(event.key=="9")
        str+="9";

 console.log(str);
 if(event.keyCode != 13){
  s=0;
  ss=0;
  }

 if (event.keyCode == 13 && s==0)
 {
    
   console.log("Enter inside div");
   document.getElementById('area').style.backgroundColor="#ff0000";

   try {
    let p=await sqlupit(str);
    if (p.length==0) throw new Error('greska');
    if (str=="") throw new Error('prazno');
    console.log(p[0].id,'----',p[0].artikl);
    myTable = document.getElementById('myTable').getElementsByTagName('tbody')[0];
 
    n = myTable.rows.length;
    console.log(myTable,'----',n);
    row=myTable.insertRow(n);
    cell1=row.insertCell(0);
    cell2=row.insertCell(1);
    cell3=row.insertCell(2);
    cell4=row.insertCell(3);
    cell5=row.insertCell(4);
    cell6=row.insertCell(5);
    cell7=row.insertCell(6);
    cell8=row.insertCell(7);
 
    cell1.innerHTML = n;
    cell2.innerHTML = p[0].id;
    cell3.innerHTML = p[0].artikl;
    cell4.innerHTML = 1;
    cell5.innerHTML = p[0].mjera;
    cell6.innerHTML = p[0].cijena.toFixed(2);;
    cell7.innerHTML = p[0].pdv;
    cell8.innerHTML = 10;
    kk=p[0].cijena;

    document.getElementById('area').style.backgroundColor="#00ff00";
    str="";
    s=1;
   } catch (e) {
    console.log("Error Message: ", e.message);
     str="";
     
 } finally {
     console.log('Proslo');
 }


 } else if (event.keyCode == 32)
 {
    let sumax=document.getElementById('right').innerHTML;
    console.log("Space inside div");
    suma=0;
    document.getElementById('right').innerHTML=suma.toFixed(2);
    printstr="";
    for(let i=0;i<=n;i++){
      console.log(myTable.rows[i].cells[3].innerHTML);
      console.log(myTable.rows[i].cells[2].innerHTML);
      console.log(myTable.rows[i].cells[7].innerHTML);
      printstr+='<tr>';
      printstr+='<td class="quantity">'+myTable.rows[i].cells[3].innerHTML+'</td>';
      printstr+='<td class="description">'+myTable.rows[i].cells[2].innerHTML+'</td>';
      printstr+='<td class="price">'+myTable.rows[i].cells[7].innerHTML+'</td>';
      printstr+='</tr>';
      }

      printstr+='<tr>';
      printstr+='<td class="quantity"></td>';
      printstr+='<td class="description">TOTAL</td>';
      printstr+='<td class="price">$'+sumax+'</td>';
      printstr+='</tr>';


      while(myTable.rows.length!=0)
      {
        myTable.deleteRow(n);
        console.log(myTable,'----',n);
        n--;
      }

    printFun(printstr);
 }

 if (event.keyCode == 13 && s==1)
 {
  ss++;
  console.log("----/////",ss);
  // cell4.innerHTML=ss;
  // cell8.innerHTML=(parseFloat(ss)*parseFloat(kk)).toFixed(2);
  myTable.rows[n].cells[3].innerHTML=ss;
  myTable.rows[n].cells[7].innerHTML=(parseFloat(ss)*parseFloat(kk)).toFixed(2);
  suma+=parseFloat(myTable.rows[n].cells[5].innerHTML);
  document.getElementById('right').innerHTML=suma.toFixed(2);
 }

});


function myCreateFunction() {

}

function myDeleteFunction() {
let myTable = document.getElementById('myTable').getElementsByTagName('tbody')[0];
n = myTable.rows.length;
document.getElementById('right').innerHTML=parseFloat(document.getElementById('right').innerHTML)-parseFloat(myTable.rows[n-1].cells[7].innerHTML);
suma-=parseFloat(myTable.rows[n-1].cells[7].innerHTML);
myTable.deleteRow(n-1);
console.log(myTable,'----',n-1);
}


function printFun(str){
  var iframe = document.createElement('iframe');
  var html = '<html><head><style>';
      html+='* {font-size: 15px;font-family: "Times New Roman";}';
      html+='td,th,tr,table {border-top: 1px solid gray;border-collapse: collapse;}';
      html+='td.description,th.description {width: 85px;max-width: 85px;}';
      html+='td.quantity,th.quantity {width: 50px;max-width: 50px;text-align:center;word-break: break-all;}';

      html+='td.price,th.price {width: 50px;max-width: 50px;text-align: left;word-break: break-all;}';
      html+='.centered {text-align: center;align-content: center;}';
      html+='.ticket {width: 185px;max-width: 185px;}';
      html+='@media print {@page {size:auto;margin:5px 0px 0px 5px;}}</style></head>';
      html+='<body>';
  
      html+='<div class="ticket">';
      html+='<table>';
      html+='<thead>';
      html+='<tr>';
      html+='<th class="quantity">Q.</th>';
      html+='<th class="description">Description</th>';
      html+='<th class="price">$$</th>';
      html+='</tr>';
      html+='</thead>';

      html+='<tbody>';
      html+=str;

      
      
      html+='</tbody>';
      html+='</table>';
      html+='<p class="centered">Hvala na posjeti</p>';
      html+='</div>';
      html+='</body></html>';





  iframe.style.display = "none";
  document.body.appendChild(iframe);
  iframe.contentWindow.document.open();
  iframe.contentWindow.document.write(html);
  iframe.contentWindow.print();
  iframe.contentWindow.document.close();


}

   



});