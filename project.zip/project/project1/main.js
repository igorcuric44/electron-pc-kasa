const { app, BrowserWindow , ipcMain} = require('electron')
const path = require('path')

let win,skladiste,unos;

const createWindow = () => {
  win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
        contextIsolation:true,
        sandbox: false,
      preload: path.join(__dirname, './preload_index.js')
    }
  })

    win.loadFile('./index.html')
    let wc=win.webContents;
    wc.openDevTools();
}

app.whenReady().then(() => {
    createWindow()
})

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
  })
  
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })

  ipcMain.handle("get/version",async (event,args)=>{
    console.log(args);
    
    skladiste=new BrowserWindow({
        //parent:win,
        width:400,
        height:300,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            sandbox: false,
            preload:path.join(__dirname,'./preload1.js'),
        },
    });
    skladiste.loadFile('./skladiste.html');
    skladiste.webContents.openDevTools();
    skladiste.show();

    //event.sender.send("skladiste","message")
    return app.getVersion();
  }
  )

  ipcMain.handle("get/unos",async (event,args)=>{
    console.log(args);
    
    unos=new BrowserWindow({
        //parent:win,
        width:400,
        height:300,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            sandbox: false,
            preload:path.join(__dirname,'./preload2.js'),
        },
    });
    unos.loadFile('./unos.html');
    unos.webContents.openDevTools();
    unos.show();

    //event.sender.send("skladiste","message")
    return app.getVersion();
  }
  )