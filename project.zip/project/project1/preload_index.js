const {contextBridge,ipcRenderer}=require('electron');

const API={
    get_version:(msg)=>ipcRenderer.invoke("get/version",msg),
    get_unos:(msg)=>ipcRenderer.invoke("get/unos",msg),
}

contextBridge.exposeInMainWorld('api',API);