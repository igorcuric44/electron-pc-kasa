const {contextBridge,ipcRenderer}=require('electron');
const sqlite3 = require('sqlite3').verbose();

let db = new sqlite3.Database('./baza.db');

const API={
    sendMsg:(msg)=>ipcRenderer.send("message-from-window1",msg),
    sqlupit:sqlupit,
}

contextBridge.exposeInMainWorld('apiblagajna',API);


var sqlupit=(id)=>{
  return new Promise((resolve,reject)=>{
  let sql = `SELECT * FROM skladiste where id=?`;
      db.all(sql,[id], function (err, rows) {
          if(err){
              console.log(err);
          }else{
          resolve(rows);
          }
      }); 
  })
  }




window.addEventListener('DOMContentLoaded', () => {
   
  document.getElementById('xx').onclick=function (){myCreateFunction()};
    
  document.getElementById('yy').addEventListener("click",myDeleteFunction);


  let str="";
  let s=0,ss=0;
  let row;
let cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8;
let myTable;
let kk;

     document.getElementById('area').addEventListener("keypress", async function(event) {
 event.preventDefault();
 console.log(event.key);
 

      if(event.key=="0")
        str+="0";
      else if(event.key=="1")
        str+="1";
      else if(event.key=="2")
        str+="2";
      else if(event.key=="3")
        str+="3";
      else if(event.key=="4")
        str+="4";
      else if(event.key=="5")
        str+="5";
      else if(event.key=="6")
        str+="6";
      else if(event.key=="7")
        str+="7";
      else if(event.key=="8")
        str+="8";
      else if(event.key=="9")
        str+="9";

 console.log(str);
 if(event.keyCode != 13){
  s=0;
  ss=0;
  }

 if (event.keyCode == 13 && s==0)
 {
  
   //document.getElementById("xx").onclick();
    
   console.log("Enter inside div");
   document.getElementById('area').style.backgroundColor="#ff0000";

   try {
   

    let p=await sqlupit(str);
    console.log(p[0].id,'----',p[0].artikl);
    myTable = document.getElementById('myTable').getElementsByTagName('tbody')[0];
 
    n = myTable.rows.length;
    console.log(myTable,'----',n);
    row=myTable.insertRow(n);
    cell1=row.insertCell(0);
    cell2=row.insertCell(1);
    cell3=row.insertCell(2);
    cell4=row.insertCell(3);
    cell5=row.insertCell(4);
    cell6=row.insertCell(5);
    cell7=row.insertCell(6);
    cell8=row.insertCell(7);
 
    cell1.innerHTML = n;
    cell2.innerHTML = p[0].id;
    cell3.innerHTML = p[0].artikl;
    cell4.innerHTML = 1;
    cell5.innerHTML = p[0].mjera;
    cell6.innerHTML = p[0].cijena.toFixed(2);;
    cell7.innerHTML = p[0].pdv;
    cell8.innerHTML = 10;
    kk=p[0].cijena;

    document.getElementById('area').style.backgroundColor="#00ff00";
    str="";
   } catch (e) {
     console.error(e);
     str="";
 } finally {
     console.log('We do cleanup here');
 }
 s=1;

 } else if (event.keyCode == 32)
 {
    
   
   console.log("Space inside div");
   
   /*
   try {
   

   let p=await sqlupit(str);
   console.log(p[0].id,'----',p[0].artikl);
   let myTable = document.getElementById('myTable').getElementsByTagName('tbody')[0];

n = myTable.rows.length;
console.log(myTable,'----',n);
let row = myTable.insertRow(n);
let cell1 = row.insertCell(0);
let cell2 = row.insertCell(1);
let cell3 = row.insertCell(2);

cell1.innerHTML = n;
cell2.innerHTML = p[0].id;
cell3.innerHTML = p[0].artikl;
   document.getElementById('area').style.backgroundColor="#00ff00";
   str="";
  } catch (e) {
    console.error(e);
    str="";
} finally {
    console.log('We do cleanup here');
}
*/


 }

 if (event.keyCode == 13 && s==1)
 {
  ss++;
  console.log("----/////",ss);
  cell4.innerHTML=ss;
  cell8.innerHTML=(parseFloat(ss)*parseFloat(kk)).toFixed(2);
  
 }

});

var n;
function myCreateFunction() {
let myTable = document.getElementById('myTable').getElementsByTagName('tbody')[0];

n = myTable.rows.length;
console.log(myTable,'----',n);
let row = myTable.insertRow(n);
let cell1 = row.insertCell(0);
let cell2 = row.insertCell(1);
let cell3 = row.insertCell(2);

cell1.innerHTML = n;
cell2.innerHTML = 'Igor';
cell3.innerHTML = 'Curic';


}

function myDeleteFunction() {
let myTable = document.getElementById('myTable').getElementsByTagName('tbody')[0];
n = myTable.rows.length;
myTable.deleteRow(n-1);
console.log(myTable,'----',n-1);
}

  
  });