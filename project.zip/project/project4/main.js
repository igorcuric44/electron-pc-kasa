const { app, BrowserWindow , ipcMain} = require('electron')
const path = require('path')

let win,skladiste,unos,blagajna;

const createWindow = () => {
  win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
        contextIsolation:true,
        sandbox: false,
      preload: path.join(__dirname, './preload_index.js')
    }
  })

    win.loadFile('./index.html')
    let wc=win.webContents;
    wc.openDevTools();
  
      win.on('closed', () => {
      win = null
      })
}

app.whenReady().then(() => {
    createWindow()
})

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
  })
  
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })


  // win.on('closed', () => {
  //   win = null
  // });

    

  ipcMain.handle("get/blagajna",async (event,args)=>{
    console.log(args);

    // if (blagajna) {
    //   blagajna.close();
    // }
    
    blagajna=new BrowserWindow({
        //parent:win,
        width:800,
        height:600,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            sandbox: false,
            preload:path.join(__dirname,'./preload1.js'),
        },
    });

    blagajna.on('closed', () => {
      blagajna=null;
      console.log("blagajna closed xxxx")
    })

    blagajna.loadFile('./blagajna.html');
    blagajna.webContents.openDevTools();
    blagajna.show();

    //event.sender.send("skladiste","message")
    return 1;
  }
  )


  ipcMain.handle("get/unos",async (event,args)=>{
    console.log(args);
    
    unos=new BrowserWindow({
        //parent:win,
        width:400,
        height:300,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            sandbox: false,
            preload:path.join(__dirname,'./preload2.js'),
        },
    });

    unos.on('closed', () => {
      unos=null;
    })

    unos.loadFile('./unos.html');
    unos.webContents.openDevTools();
    unos.show();

    //event.sender.send("skladiste","message")
    return 1;
  }
  )
 


  ipcMain.handle("get/version",async (event,args)=>{
    console.log(args);

    
    
    skladiste=new BrowserWindow({
        //parent:win,
        width:600,
        height:800,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            sandbox: false,
            preload:path.join(__dirname,'./preload3.js'),
        },
    });

    skladiste.on('closed', () => {
      skladiste= null
  })

    skladiste.loadFile('./skladiste.html');
    skladiste.webContents.openDevTools();
    skladiste.show();

    //event.sender.send("skladiste","message")
    return 1;
  }
  )

 
  ipcMain.on('message-from-window1',(event,args)=>{
    //win.webContents.send("message-enable-button1","enable 1");
    console.log('main received prozor 1',args);
    blagajna.close();
    blagajna=!blagajna;
    
})

  ipcMain.on('message-from-window2',(event,args)=>{
    //win.webContents.send("message-enable-button1","enable 1");
    console.log('main received prozor 2',args);
    unos.close();
    unos=!unos;
})

  ipcMain.on('message-from-window3',(event,args)=>{
    //win.webContents.send("message-enable-button1","enable 1");
    console.log('main received prozor 3',args);
    skladiste.close();
    skladiste=!skladiste;
})


ipcMain.on('get/izlaz',(event,args)=>{
  //win.webContents.send("message-enable-button1","enable 1");
  console.log('main received ',args);
  
  if (skladiste) {
    skladiste.close();
    console.log("skladiste closed");
  }

  if (unos) {
    unos.close();
    console.log("Unos closed");
  }
   

  if (blagajna) {
    blagajna.close();
    console.log("Blagajna closed");
  }

  //win.close();
  //unos.close();
  win.close();
  console.log("win closed");

})

