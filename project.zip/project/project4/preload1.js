const {contextBridge,ipcRenderer}=require('electron');
const sqlite3 = require('sqlite3').verbose();

let db = new sqlite3.Database('./baza.db');

const API={
    sendMsg:(msg)=>ipcRenderer.send("message-from-window1",msg),
    sqlupit:sqlupit,
}

contextBridge.exposeInMainWorld('apiblagajna',API);


var sqlupit=(id)=>{
  return new Promise((resolve,reject)=>{
  let sql = `SELECT * FROM skladiste where id=?`;
      db.all(sql,[id], function (err, rows) {
          if(err){
              console.log(err);
          }else{
          resolve(rows);
          }
      }); 
  })
  }




window.addEventListener('DOMContentLoaded', () => {
   
  document.getElementById('xx').onclick=function (){myCreateFunction()};
    
  document.getElementById('yy').addEventListener("click",myDeleteFunction);


  let str="";
  let s=0,ss=0;

     document.getElementById('area').addEventListener("keypress", async function(event) {
 event.preventDefault();
 console.log(event.key);

      if(event.key=="0")
        str+="0";
      else if(event.key=="1")
        str+="1";
      else if(event.key=="2")
        str+="2";
      else if(event.key=="3")
        str+="3";
      else if(event.key=="4")
        str+="4";
      else if(event.key=="5")
        str+="5";
      else if(event.key=="6")
        str+="6";
      else if(event.key=="7")
        str+="7";
      else if(event.key=="8")
        str+="8";
      else if(event.key=="9")
        str+="9";

 console.log(str);
 if (event.keyCode == 13)
 {
  
   document.getElementById("xx").onclick();
    
   console.log("Enter inside div");
   document.getElementById('area').style.backgroundColor="#ff0000";
 } else if (event.keyCode == 32)
 {
    
   
   console.log("Space inside div");
   try {
   

   let p=await sqlupit(str);
   console.log(p[0].id,'----',p[0].artikl);
   let myTable = document.getElementById('myTable').getElementsByTagName('tbody')[0];

n = myTable.rows.length;
console.log(myTable,'----',n);
let row = myTable.insertRow(n);
let cell1 = row.insertCell(0);
let cell2 = row.insertCell(1);
let cell3 = row.insertCell(2);

cell1.innerHTML = n;
cell2.innerHTML = p[0].id;
cell3.innerHTML = p[0].artikl;
   document.getElementById('area').style.backgroundColor="#00ff00";
   str="";
  } catch (e) {
    console.error(e);
    str="";
} finally {
    console.log('We do cleanup here');
}



 }
});

var n;
function myCreateFunction() {
let myTable = document.getElementById('myTable').getElementsByTagName('tbody')[0];

n = myTable.rows.length;
console.log(myTable,'----',n);
let row = myTable.insertRow(n);
let cell1 = row.insertCell(0);
let cell2 = row.insertCell(1);
let cell3 = row.insertCell(2);

cell1.innerHTML = n;
cell2.innerHTML = 'Igor';
cell3.innerHTML = 'Curic';


}

function myDeleteFunction() {
let myTable = document.getElementById('myTable').getElementsByTagName('tbody')[0];
n = myTable.rows.length;
myTable.deleteRow(n-1);
console.log(myTable,'----',n-1);
}

  
  });