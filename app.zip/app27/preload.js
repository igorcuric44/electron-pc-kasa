const {contextBridge,ipcRenderer}=require('electron');
const win = require('electron').remote.getCurrentWindow();

const API={
    closeButton:()=>{win.close()},
 
}





contextBridge.exposeInMainWorld('api',API);

