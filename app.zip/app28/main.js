const {ipcMain,app,BrowserWindow,Menu,screen}=require('electron');
const path=require('path');


let isMaximized = true;
let win,child;
let width,height;

function createWindow(){
     width=screen.getPrimaryDisplay().workAreaSize.width;
     height=screen.getPrimaryDisplay().workAreaSize.height;

    win=new BrowserWindow({
        width:width/2,
        height:height/1.4,
        title:"awesome app",
        frame: false,
        webPreferences:{
            nodeIntegration:true,
            preload:path.join(__dirname,'./preload.js'),
        },
    })
    win.loadFile('./index.html');
    win.on('show', () => { win.focus(); });
    //child.show();
    win.webContents.openDevTools();
}

app.whenReady().then(()=>{
    console.log('main: app is ready creating window');
    createWindow();
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
  })
  
app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })


ipcMain.on('close-message',(event,args)=>{
    //event.sender.send('read-file-success','pong');
     console.log('main received ',args);
     win.close();
    
})

ipcMain.on('maximize-message',(event,args)=>{
    //event.sender.send('read-file-success','pong');
     console.log('main received ',args);
     isMaximized = !isMaximized;
     isMaximized ? win.unmaximize() : win.maximize();
    
})

ipcMain.on('minimize-message',(event,args)=>{
    //event.sender.send('read-file-success','pong');
     console.log('main received ',args);
     win.minimize();
     
})

ipcMain.on('dimension-message',(event,args)=>{
    //event.sender.send('read-file-success','pong');
     console.log('main received ',args);
     console.log(width);
     console.log(height);
})