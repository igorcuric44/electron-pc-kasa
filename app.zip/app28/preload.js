const {contextBridge,ipcRenderer}=require('electron');
//const winx= require('electron').remote.getCurrentWindow();

const func={
    maximizeMsg:(msg)=>ipcRenderer.send("maximize-message",msg),
    minimizeMsg:(msg)=>ipcRenderer.send("minimize-message",msg),
    closeMsg:(msg)=>ipcRenderer.send("close-message",msg),
    dimensionMsg:(msg)=>ipcRenderer.send("dimension-message",msg)
 }


contextBridge.exposeInMainWorld('poruka',func);
