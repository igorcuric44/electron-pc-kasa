const fs=require('fs');
const path=require('path');
const {BrowserWindow,app,ipcMain}=require('electron');
const sqlite3 = require('sqlite3').verbose();

// open the database
let db = new sqlite3.Database('./chinook.db');


const createWindow=()=>{
    const win=new BrowserWindow({
        webPreferences:{
            preload:path.join(__dirname,'./preload.js'),
            },
        })
    
        win.loadFile('index.html');
        let wc=win.webContents;
        wc.openDevTools();

}

app.whenReady().then(()=>{
    console.log('main: app is ready creating window');
    createWindow();
});


app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
  })
  
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })

  var myPromise=()=>{
    return new Promise((resolve,reject)=>{
    let sql = `SELECT * FROM playlists`;
        db.all(sql, function (err, rows) {
            if(err){
                console.log(err);
            }else{
            resolve(rows);
            }
        }); 
    })
    }

ipcMain.on('message',(event,args)=>{
  

    //event.sender.send('read-file-success','pong');

    console.log('main received ',args);

    //const fileContent=fs.readFileSync('./read.txt',{encoding:'utf-8'});


    async function sqlwait(){
      var result=await myPromise();
      console.log("///",result);
      event.sender.send('message-back',result);
  }

  sqlwait(); 
        
})

