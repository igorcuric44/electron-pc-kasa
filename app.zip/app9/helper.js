function greetings() {
    alert("Using ESM import/export syntax");
  }
  
  export { greetings };
  