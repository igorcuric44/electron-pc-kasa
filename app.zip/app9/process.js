import { greetings } from "./helper.js";

greetings();


