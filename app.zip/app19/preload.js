const {contextBridge,ipcRenderer}=require('electron');


const API={
    sendMsg:(msg)=>ipcRenderer.send("message",msg),
    onCount:(func)=>ipcRenderer.on('count',(event,args)=>
    {func(args);}),
    sendPromise:(msg)=>ipcRenderer.invoke("promise-msg",msg),

}

contextBridge.exposeInMainWorld('api',API);