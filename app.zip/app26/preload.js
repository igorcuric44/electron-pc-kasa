const {contextBridge,ipcRenderer}=require('electron');


const API={
    sendMsg:(msg)=>ipcRenderer.send("message",msg),
 
}

const API1={
    sendMsg:(msg)=>ipcRenderer.send("message1",msg),
 
}



contextBridge.exposeInMainWorld('api',API);

contextBridge.exposeInMainWorld('api1',API1);