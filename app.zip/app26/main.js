const {ipcMain,app,BrowserWindow,Menu}=require('electron');
const path=require('path');


let win,child;

function createWindow(){
    win=new BrowserWindow({
        width:800,
        height:600,
        title:"awesome app",
        webPreferences:{
            nodeIntegration:true,
            preload:path.join(__dirname,'./preload.js'),
        },
    })
    win.loadFile('./index.html');
    win.on('show', () => { win.focus(); });
    //child.show();
    win.webContents.openDevTools();
}

app.whenReady().then(()=>{
    console.log('main: app is ready creating window');
    createWindow();
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
  })
  
app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })


ipcMain.on('message',(event,args)=>{
    //event.sender.send('read-file-success','pong');

    console.log('main received ',args);
    child=new BrowserWindow({
        parent:win,
        width:400,
        height:300,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            preload:path.join(__dirname,'./preload.js'),
        },
    });
    child.loadFile('./child.html');
    child.webContents.openDevTools();
    child.on('show', () => { child.focus(); });
    child.show();
    child.blur(); 

})


ipcMain.on('message1',(event,args)=>{
    //event.sender.send('read-file-success','pong');
    console.log('main received  prozor 2',args);
    child.close();
})