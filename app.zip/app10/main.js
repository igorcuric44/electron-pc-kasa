const {app,BrowserWindow,session}=require('electron');
const path=require('path');
const {ipcMain}=require('electron');
const fs=require('fs');

var mainWindow;

function createWindow() {
    mainWindow=new BrowserWindow({
        width:600,
        height:600,
        title:'Amplify Adwatcher Collection',
//icon:'log.png'

webPreferences:{
    contextIsolation:true,
    nodeIntegration:false,
    //preload:path.join(__dirname,'./index_preload.js')
    preload: path.join(__dirname,'index_preload.js')
}})

//mainWindow.setMenu(null);
mainWindow.loadFile('./index.html');

let wc=mainwindow.webContents;
wc.openDevTools();

}


app.whenReady().then(()=>{
    createWindow();
    mainWindow.maximize();
    app.on('activate',function(){
        if(BrowserWindow.getAllWindow().length===0) createWindow();
    });

})



app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
  })

ipcMain.on('gotLead',(event,load)=>
{
    console.log('Main Process > gotLead');
    console.log(lead);
    let leadStr=JSON.stringify(lead);
    fs.writeFileSync("mzlead.json",leadStr);
});
