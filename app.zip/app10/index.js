document.querySelector("#btnSend").addEventListener("click",(event,arg)=>
{
    console.log("View script > submit clicked");

    let lead={
        name:document.querySelector("#name").value,
        comment:document.querySelector("#comment").value
    }

    window.Bridge.sendSubmit(lead);

    alert("Clicked");
}
)