const {contextBridge,ipcRenderer}=require('electron');


const API4={
    sendMsg:(msg)=>ipcRenderer.send("message-from-window4",msg),
 
}



contextBridge.exposeInMainWorld('api1',API4);