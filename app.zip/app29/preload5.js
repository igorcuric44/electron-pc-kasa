const {contextBridge,ipcRenderer}=require('electron');


const API5={
    sendMsg:(msg)=>ipcRenderer.send("message-from-window5",msg),
 
}



contextBridge.exposeInMainWorld('api1',API5);