const {contextBridge,ipcRenderer}=require('electron');


const API={
    sendMsgWin1:(msg)=>ipcRenderer.send("message-window1",msg),
    sendMsgWin2:(msg)=>ipcRenderer.send("message-window2",msg),
    sendMsgWin3:(msg)=>ipcRenderer.send("message-window3",msg),
    sendMsgWin4:(msg)=>ipcRenderer.send("message-window4",msg),
    sendMsgWin5:(msg)=>ipcRenderer.send("message-window5",msg),

    //getMsgWin1:(msg)=>ipcRenderer.on("message-from-main1"),
}

contextBridge.exposeInMainWorld('api',API);


/*
const API1={
    sendMsg:(msg)=>ipcRenderer.send("message1",msg),
 
}

contextBridge.exposeInMainWorld('api1',API1);

*/