const {contextBridge,ipcRenderer}=require('electron');


const API2={
    sendMsg:(msg)=>ipcRenderer.send("message-from-window2",msg),
 
}



contextBridge.exposeInMainWorld('api1',API2);