const {contextBridge,ipcRenderer}=require('electron');


const API1={
    sendMsg:(msg)=>ipcRenderer.send("message-from-window1",msg),
 
}



contextBridge.exposeInMainWorld('api1',API1);