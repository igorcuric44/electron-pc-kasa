const {contextBridge,ipcRenderer}=require('electron');


const API3={
    sendMsg:(msg)=>ipcRenderer.send("message-from-window3",msg),
 
}



contextBridge.exposeInMainWorld('api1',API3);