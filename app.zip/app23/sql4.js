const sqlite3 = require('sqlite3').verbose();

// open the database
let db = new sqlite3.Database('./chinook.db');

let sql = `SELECT Name FROM playlists`;

function getName(callback){
var name = null;
db.all(sql, function (err, rows) {
    if(err){
        console.log(err);
    }else{
    console.log(rows);
    name=rows;
    }
});
return name; 
}

getName();

console.log(getName());
// close the database connection
db.close();