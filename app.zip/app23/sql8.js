const sqlite3 = require('sqlite3').verbose();

// open the database
let db = new sqlite3.Database('./chinook.db');



var myPromise=()=>{
return new Promise((resolve,reject)=>{
let sql = `SELECT * FROM playlists`;
    db.all(sql, function (err, rows) {
        if(err){
            console.log(err);
        }else{
        resolve(rows);
        }
    }); 
})
}


async function sqlwait(){
    var result=await myPromise();
    console.log("///",result);
}

sqlwait();

db.close();