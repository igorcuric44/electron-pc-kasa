const sqlite3 = require('sqlite3').verbose();

// open the database
let db = new sqlite3.Database('./chinook.db');



function getName(callback){
let sql = `SELECT * FROM playlists`;
    db.all(sql, function (err, rows) {
        if(err){
            console.log(err);
        }else{
        callback(rows);
        }
    }); 
}

function print(name) {
    console.log(name);
  }

getName(print);
// close the database connection
db.close();