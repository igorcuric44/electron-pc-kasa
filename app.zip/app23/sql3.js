const sqlite3 = require('sqlite3').verbose();

// open the database
let db = new sqlite3.Database('./chinook.db');


const getName=()=>{         
    let sql = `SELECT Name name FROM playlists`;
    let stmt=db.prepare(sql);
    let res=stmt.all();

    return res;
}

console.log(getName());

// close the database connection
db.close();