const sqlite3 = require('sqlite3').verbose();

// open the database
let db = new sqlite3.Database('./chinook.db');

let sql = `SELECT DISTINCT Name name FROM playlists
           ORDER BY name`;

const getName=()=>{         
var p;
var p=db.all(sql, [], (err, rows) => {
  if (err) {
    throw err;
  }
 //console.log(rows);
 
 //console.log(p);
 return rows;

});
return p;
}

var t=getName();
console.log(t);

// close the database connection
db.close();