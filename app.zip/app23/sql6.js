const sqlite3 = require('sqlite3').verbose();

// open the database
let db = new sqlite3.Database('./chinook.db');



const myPromise=new Promise((resolve,reject)=>{
let sql = `SELECT * FROM playlists`;
    db.all(sql, function (err, rows) {
        if(err){
            console.log(err);
        }else{
        resolve(rows);
        }
    }); 
})


myPromise.then(res=>console.log(res));
// close the database connection
db.close();