const {ipcMain,app,BrowserWindow,Menu}=require('electron');
const path=require('path');


let win,child1,child2,child3,child4,child5;

let i=0;

function createWindow(){
    win=new BrowserWindow({
        width:800,
        height:600,
        title:"awesome app",
        webPreferences:{
            nodeIntegration:true,
            preload:path.join(__dirname,'./preload_index.js'),
        },
    })
    win.loadFile('./index.html');
    win.webContents.openDevTools();
}

app.whenReady().then(()=>{
    console.log('main: app is ready creating window');
    createWindow();
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
  })
  
app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })


  

ipcMain.on('message-window1',(event,args)=>{
    console.log('main received ',args);
    child1=new BrowserWindow({
        //parent:win,
        width:400,
        height:300,
        //modal: true, show: false ,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            preload:path.join(__dirname,'./preload1.js'),
        },
    });
    child1.loadFile('./child1.html');
    child1.webContents.openDevTools();
    child1.show();
    event.sender.send("message-back-window1","ping "+i);
    i++;
})

ipcMain.on('message-window2',(event,args)=>{
    console.log('main received ',args);
    child2=new BrowserWindow({
        width:400,
        height:300,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            preload:path.join(__dirname,'./preload2.js'),
        },
    });
    child2.loadFile('./child2.html');
    child2.webContents.openDevTools();
    child2.show();
    event.sender.send("message-back-window2","ping "+i);
    i++;
})

ipcMain.on('message-window3',(event,args)=>{
    console.log('main received ',args);
    child3=new BrowserWindow({
        width:400,
        height:300,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            preload:path.join(__dirname,'./preload3.js'),
        },
    });
    child3.loadFile('./child3.html');
    child3.webContents.openDevTools();
    child3.show();
    event.sender.send("message-back-window3","ping "+i);
    i++;
})


ipcMain.on('message-window4',(event,args)=>{
    console.log('main received ',args);
    child4=new BrowserWindow({
        width:400,
        height:300,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            preload:path.join(__dirname,'./preload4.js'),
        },
    });
    child4.loadFile('./child4.html');
    child4.webContents.openDevTools();
    child4.show();
    event.sender.send("message-back-window4","ping "+i);
    i++;
})


ipcMain.on('message-window5',(event,args)=>{
    console.log('main received ',args);
    child5=new BrowserWindow({
        width:400,
        height:300,
        title:"CHILD",
        webPreferences:{
            nodeIntegration:true,
            preload:path.join(__dirname,'./preload5.js'),
        },
    });
    child5.loadFile('./child5.html');
    child5.webContents.openDevTools();
    child5.show();
    event.sender.send("message-back-window5","ping "+i);
    i++;
})


ipcMain.on('message-from-window1',(event,args)=>{
    win.webContents.send("message-enable-button1","enable 1");
    console.log('main received  prozor 1',args);
    child1.close();
})

ipcMain.on('message-from-window2',(event,args)=>{
    win.webContents.send("message-enable-button2","enable 2");
    console.log('main received  prozor 2',args);
    child2.close();
})

ipcMain.on('message-from-window3',(event,args)=>{
    win.webContents.send("message-enable-button3","enable 3");
    console.log('main received  prozor 3',args);
    child3.close();
})


ipcMain.on('message-from-window4',(event,args)=>{
    win.webContents.send("message-enable-button4","enable 4");
    console.log('main received  prozor 4',args);
    child4.close();
})

ipcMain.on('message-from-window5',(event,args)=>{
    win.webContents.send("message-enable-button5","enable 5");
    console.log('main received  prozor 5',args);
    child5.close();
})
