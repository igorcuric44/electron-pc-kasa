const {contextBridge,ipcMain,ipcRenderer}=require('electron');
const fs=require('fs');
const path=require('path');


var back;
var forward_message1;


let sendSubmit=()=>{
    ipcRenderer.send('forward',"ping");
  
}


ipcRenderer.on('nazad',(event,arg)=>
{
    console.log(arg);
    forward_message1=arg;
    console.log("///",forward_message1);
    /*
    back={
      forward_message1:arg
  }*/
});

//contextBridge.exposeInMainWorld('Bridge1',back);


  contextBridge.exposeInMainWorld('Bridge1',{
    //forward_message1:"igor",
    //forward_message1:forward_message11
});




let indexBridge={
    sendSubmit:sendSubmit,
    forward_message1:"igor",
}

contextBridge.exposeInMainWorld('Bridge',indexBridge);

/*
let indexBridge1={
    forward_message:forward_message1,
}

contextBridge.exposeInMainWorld('Bridge1',indexBridge1);

*/

window.Bridge;