const {app,BrowserWindow,Menu}=require('electron');



function createWindow(){
    const win=new BrowserWindow({
        width:800,
        height:600,
        title:"awesome app",
        webPreferences:{
            nodeIntegration:true,
        },
    })
    win.loadFile('./index.html');


    let child=new BrowserWindow({parent:win});
    child.loadFile('./child.html');
    child.show();


    win.webContents.openDevTools();
}

app.whenReady().then(createWindow);


