const {contextBridge,ipcRenderer}=require('electron');


const API={
    sendMsg:(msg)=>ipcRenderer.send("message",msg),
    onCount:(func)=>ipcRenderer.on('count',(event,args)=>
    {func(args);})

}

contextBridge.exposeInMainWorld('api',API);