const {contextBridge,ipcMain,ipcRenderer}=require('electron');
const fs=require('fs');
const path=require('path');


let indexBridge={
    somethinghappend:(callback)=>ipcRenderer.on('somethinghappend',(callback))
}

contextBridge.exposeInMainWorld("indexBridge",indexBridge);


