const { app, BrowserWindow , ipcMain} = require('electron')
const path = require('path')
const fs=require('fs');

var win;

let icounter=0;

const createWindow = () => {
    win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
        contextIsolation:true,
        sandbox: false,
        preload: path.join(__dirname, 'preload.js')
    }
  })

 // win.setMenu(null);
  win.loadFile('index.html')
 
  setInterval(()=>{
    icounter++;
    win.webContents.send("somethinghappend",icounter)
    },1500);

    let wc=win.webContents;
    wc.openDevTools();

}

app.whenReady().then(() => {
    
    createWindow();
    win.maximize();

})

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
  })
  
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })
