const {contextBridge,ipcRenderer}=require('electron');


contextBridge.exposeInMainWorld('api',{
    readFile:()=>{
        ipcRenderer.send('read-file',"ping");


},
})


contextBridge.exposeInMainWorld("preload", {
    onFile: (func) => ipcRenderer.on("read-file-success", (event,arg)=>
    func(event,arg))}
    );
 