const fs=require('fs');
const path=require('path');
const {BrowserWindow,app,ipcMain}=require('electron');

const createWindow=()=>{
    const win=new BrowserWindow({
        webPreferences:{
            preload:path.join(__dirname,'./preload.js'),
            },
        })
    
        win.loadFile('index.html');
        let wc=win.webContents;
        wc.openDevTools();

}

app.whenReady().then(()=>{
    console.log('main: app is ready creating window');
    createWindow();
});


ipcMain.on('read-file',(event,data)=>{
    console.log('main: received file event');

    event.sender.send('read-file-success','pong');

    console.log('main: sent ',data);
    
})

