let fs = require('fs');
const electron = require('electron')
// Get the file contents before the append operation
console.log("\nFile Contents of file before append:",
  fs.readFileSync("example_file.txt", "utf8"));
  
fs.appendFileSync("example_file.txt", " - Geeks For Geeks");
  
// Get the file contents after the append operation
console.log("\nFile Contents of file after append:",
       fs.readFileSync("example_file.txt", "utf8"));