const { app, BrowserWindow } = require('electron');

app.whenReady().then(() => {
    const window = new BrowserWindow({ 
        webPreferences: { 
          nodeIntegration: true 
        } 
      });
  window.loadFile('./index.html');
});



