const {contextBridge,ipcRenderer}=require('electron');


contextBridge.exposeInMainWorld('api',{
    readFile:()=>{
        ipcRenderer.send('read-file');

        return new Promise((resolve)=>ipcRenderer.on('read-file-success',(event,data)=>resolve({event,data}))
)},
})