const fs=require('fs');
const path=require('path');
const {BrowserWindow,app,ipcMain}=require('electron');

const createWindow=()=>{
    const win=new BrowserWindow({
        webPreferences:{
            preload:path.join(__dirname,'./preload.js'),
            },
        })
    
        win.loadFile('index.html');
        let wc=win.webContents;
        wc.openDevTools();

}

app.whenReady().then(()=>{
    console.log('main: app is ready creating window');
    createWindow();
});


ipcMain.on('read-file',event=>{
    console.log('main: received file event');

    const fileContent=fs.readFileSync('./file-to-read.txt',
    {encoding:'utf-8'});

    event.sender.send('read-file-success',fileContent);

    console.log('main: sent read-file-success event');
    
})


