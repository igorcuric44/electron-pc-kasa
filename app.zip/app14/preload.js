const {contextBridge,ipcMain,ipcRenderer}=require('electron');
const fs=require('fs');
const path=require('path');

contextBridge.exposeInMainWorld('versions', {
    node: () => process.versions.node
    // we can also expose variables, not just functions
  })


let sendSubmit=async (lead)=>{
    console.log(lead);
    console.log('Renderer Process > sendSubmit');
    let result=await ipcRenderer.invoke('gotLead',lead);
    setTimeout(()=>{}, 5000);
    console.log(`RESULT ${result}`);
    
}

let indexBridge={
    sendSubmit:sendSubmit
}

contextBridge.exposeInMainWorld('Bridge',indexBridge);

let sendSubmit1=(lead1)=>{
   
    ipcRenderer.send('prozor',lead1);
}

let indexBridge1={
    sendSubmit:sendSubmit
}

contextBridge.exposeInMainWorld('Bridge1',indexBridge1);