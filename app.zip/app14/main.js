const { app, BrowserWindow , ipcMain} = require('electron')
const path = require('path')
const fs=require('fs');
const {dialog}=require('electron');

const createWindow = () => {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
        sandbox: false,
        contextIsolation:true,
        nodeIntegration:false,
      preload: path.join(__dirname, 'preload.js')
    }
  })

  win.loadFile('index.html')
  let wc=win.webContents;
  wc.openDevTools();

}

app.whenReady().then(() => {
    
    createWindow()
})

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
  })
  
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })

  ipcMain.handle('gotLead',(event,lead)=>
{
    console.log('Main Process > gotLead');
    console.log(lead);
    let leadStr=JSON.stringify(lead);
    fs.writeFileSync("mylead.json",leadStr);

    return true;
});

let poruka="";

ipcMain.on('prozor',(event,poruka1)=>
{
    console.log('Main Process > poruka1');
   // console.log(poruka1);
});


ipcMain.send('prozor',poruka);