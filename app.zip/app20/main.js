const fs=require('fs');
const path=require('path');
const {BrowserWindow,app,ipcMain}=require('electron');

const createWindow=()=>{
    const win=new BrowserWindow({
        webPreferences:{
            preload:path.join(__dirname,'./preload.js'),
            },
        })
    
        win.loadFile('index.html');
        let wc=win.webContents;
        wc.openDevTools();

}

app.whenReady().then(()=>{
    console.log('main: app is ready creating window');
    createWindow();
});


app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
  })
  
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })




ipcMain.on('message',(event,args)=>{

    //event.sender.send('read-file-success','pong');

    console.log('main received ',args);

    event.sender.send('message-back','pong');
        
})

