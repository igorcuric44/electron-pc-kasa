const {contextBridge,ipcRenderer}=require('electron');


const API={
    sendMsg:(msg)=>ipcRenderer.send("message",msg),
    getMsg:(func)=>ipcRenderer.on('message-back',(event,args)=>
    {func(args);}),
   

}

contextBridge.exposeInMainWorld('api',API);