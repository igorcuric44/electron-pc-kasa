const { app, BrowserWindow , ipcMain} = require('electron')
const path = require('path')
const fs=require('fs');
const {dialog}=require('electron');

const createWindow = () => {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
        sandbox: false,
        contextIsolation:true,
        nodeIntegration:false,
      preload: path.join(__dirname, 'preload.js')
    }
  })

  win.loadFile('index.html')
  let wc=win.webContents;
  wc.openDevTools();

/*
  wc.on('dom-ready',(e)=>
  {
    dialog.showMessageBox((options={
        message:"I got called from a WebContent Object",
        title:"This is a message"
    })
  ).then(res=>{
    console.log(res);
  });
});
*/


wc.on('dom-ready',(e)=>{
    dialog.showMessageBox(
    (options={
    message:'I got called from a WebContent Object',
    title:'This is nessage',
})
).then((res)=>{
    console.log(res);
  });
}).focus();


}

app.whenReady().then(() => {
    
    createWindow()
})

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit()
    }
  })
  
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })

  ipcMain.on('gotLead',(event,lead)=>
{
    console.log('Main Process > gotLead');
    console.log(lead);
    let leadStr=JSON.stringify(lead);
    fs.writeFileSync("mylead.json",leadStr);
});